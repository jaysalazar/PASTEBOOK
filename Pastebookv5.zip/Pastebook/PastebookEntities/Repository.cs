﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace PastebookDataAccess
{
    // source: http://www.tugberkugurlu.com/archive/generic-repository-pattern-entity-framework-asp-net-mvc-and-unit-testing-triangle
    public class Repository<T> where T : class
    {
        private readonly R entity;



        public virtual int Add(T entity)
        {
            int returnValue = 0;

            using (var context = new PASTEBOOK_DBEntities())
            {
                try
                {
                    context.Entry(entity).State = System.Data.Entity.EntityState.Added;
                    returnValue = context.SaveChanges();
                }
                catch (Exception ex)
                {
                    List<Exception> exceptionList = new List<Exception>();
                    exceptionList.Add(ex);
                    foreach (var exception in exceptionList)
                    {
                        throw new Exception(exception.Message, ex);
                    }
                }
            }

            return returnValue;
        }

        public virtual int Edit(T entity)
        {
            int returnValue = 0;

            using (var context = new PASTEBOOK_DBEntities())
            {
                try
                {
                    context.Entry(entity).State = System.Data.Entity.EntityState.Modified;
                    returnValue = context.SaveChanges();
                }
                catch (Exception ex)
                {
                    List<Exception> exceptionList = new List<Exception>();
                    exceptionList.Add(ex);
                    foreach (var exception in exceptionList)
                    {
                        throw new Exception(exception.Message, ex);
                    }
                }
            }

            return returnValue;
        }

        public virtual int Delete(T entity)
        {
            int returnValue = 0;

            using (var context = new PASTEBOOK_DBEntities())
            {
                try
                {
                    context.Entry(entity).State = System.Data.Entity.EntityState.Deleted;
                    returnValue = context.SaveChanges();
                }
                catch (Exception ex)
                {
                    List<Exception> exceptionList = new List<Exception>();
                    exceptionList.Add(ex);
                    foreach (var exception in exceptionList)
                    {
                        throw new Exception(exception.Message, ex);
                    }
                }
            }

            return returnValue;
        }

        public virtual T Retrieve(Expression<Func<T, bool>> predicate)
        {
            T result = null;

            using (var context = new PASTEBOOK_DBEntities())
            {
                try
                {
                    result = context.Set<T>().Where(predicate).SingleOrDefault();
                }
                catch (Exception ex)
                {
                    List<Exception> exceptionList = new List<Exception>();
                    exceptionList.Add(ex);
                    foreach (var exception in exceptionList)
                    {
                        throw new Exception(exception.Message, ex);
                    }
                }
            }

            return result;
        }

        public virtual IEnumerable<T> RetrieveAll(Expression<Func<T, bool>> predicate)
        {
            IEnumerable<T> result = null;

            using (var context = new PASTEBOOK_DBEntities())
            {
                try
                {
                    result = context.Set<T>().Where(predicate);
                }
                catch (Exception ex)
                {
                    List<Exception> exceptionList = new List<Exception>();
                    exceptionList.Add(ex);
                    foreach (var exception in exceptionList)
                    {
                        throw new Exception(exception.Message, ex);
                    }
                }
            }

            return result;
        }
    }
}
