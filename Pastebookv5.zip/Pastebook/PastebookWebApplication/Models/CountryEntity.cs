﻿namespace PastebookBusinessLogic.Entities
{
    public class CountryEntity
    {
        public int CountryId { get; set; }

        public string Country { get; set; }
    }
}
