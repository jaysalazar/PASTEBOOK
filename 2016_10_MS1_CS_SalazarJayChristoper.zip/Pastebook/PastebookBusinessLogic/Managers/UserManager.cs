﻿using PastebookDataAccess;
using PastebookEntityFramework;
using System;
using System.Collections.Generic;

namespace PastebookBusinessLogic.Managers
{
    public class UserManager : Repository<PB_USER>
    {
        public int CreateUser(PB_USER userModel)
        {
            PasswordManager passwordManager = new PasswordManager();
            string salt = "";

            userModel.PASSWORD = passwordManager.GeneratePasswordHash(userModel.PASSWORD, out salt);
            userModel.SALT = salt;
            userModel.DATE_CREATED = DateTime.UtcNow;
            userModel.BIRTHDAY = userModel.BIRTHDAY.ToUniversalTime();

            int result = Add(userModel);

            return result;
        }

        public int UpdateUser(PB_USER userModel)
        {
            userModel.BIRTHDAY = userModel.BIRTHDAY.ToUniversalTime();
            userModel.DATE_CREATED = userModel.DATE_CREATED.ToUniversalTime();

            int result = Edit(userModel);

            return result;
        }

        public PB_USER RetrieveUserByID(int userID)
        {
            PB_USER userModel = new PB_USER();

            userModel = RetrieveSpecific(x => x.ID == userID);

            userModel.BIRTHDAY = userModel.BIRTHDAY.ToLocalTime();
            userModel.DATE_CREATED = userModel.DATE_CREATED.ToLocalTime();

            return userModel;
        }

        public PB_USER RetrieveUserByEmail(string email)
        {
            PB_USER userModel = new PB_USER();

            userModel = RetrieveSpecific(x => x.EMAIL_ADDRESS == email);

            userModel.BIRTHDAY = userModel.BIRTHDAY.ToLocalTime();
            userModel.DATE_CREATED = userModel.DATE_CREATED.ToLocalTime();

            return userModel;
        }

        public List<PB_USER> SearchUsers(string name)
        {
            List<PB_USER> users = new List<PB_USER>();

            var result = Retrieve(x => x.FIRST_NAME.Contains(name) || x.LAST_NAME.Contains(name));

            foreach (var user in result)
            {
                user.BIRTHDAY = user.BIRTHDAY.ToLocalTime();
                user.DATE_CREATED = user.DATE_CREATED.ToLocalTime();
                users.Add(user);
            }

            return users;
        }

        public bool CheckEmailAddress(string emailAddress)
        {
            bool result = Check(x => x.EMAIL_ADDRESS == emailAddress);

            return result;
        }

        public bool CheckUsername(string username)
        {
            bool result = Check(x => x.USER_NAME == username);

            return result;
        }

        public bool CheckPassword(string email, string password)
        {
            PB_USER usermodel = new PB_USER();
            PasswordManager passwordManager = new PasswordManager();

            usermodel = RetrieveUserByEmail(email);

            bool result = passwordManager.IsPasswordMatch(password, usermodel.SALT, usermodel.PASSWORD);

            return result;
        }
    }
}