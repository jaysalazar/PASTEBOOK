﻿using PastebookDataAccess;
using PastebookEntityFramework;
using System.Collections.Generic;

namespace PastebookBusinessLogic.Managers
{
    public class CountryManager : Repository<REF_COUNTRY>
    {
        public List<REF_COUNTRY> RetrieveAllCountries()
        {
            List<REF_COUNTRY> countries = new List<REF_COUNTRY>();

            countries = RetrieveAll();

            return countries;
        }
    }
}
