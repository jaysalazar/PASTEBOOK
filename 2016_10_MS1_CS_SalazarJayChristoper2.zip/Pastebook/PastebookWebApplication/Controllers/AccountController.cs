﻿using PastebookBusinessLogic.Managers;
using PastebookEntityFramework;
using PastebookWebApplication.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace PastebookWebApplication.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public ActionResult Register()
        {
            if (Session["CurrentUserID"] != null)
            {
                return RedirectToAction("Index", "Home");
            }

            List<REF_COUNTRY> countries = new List<REF_COUNTRY>();
            CountryManager countryManager = new CountryManager();
            UserManager userManager = new UserManager();

            countries = countryManager.RetrieveAllCountries();

            RegisterViewModel model = new RegisterViewModel
            {
                Countries = countries
            };

            return View(model);
        }

        [HttpPost]
        public ActionResult Register(RegisterViewModel model)
        {
            List<REF_COUNTRY> countries = new List<REF_COUNTRY>();
            CountryManager countryManager = new CountryManager();
            UserManager userManager = new UserManager();

            countries = countryManager.RetrieveAllCountries();

            // check any existing email
            if (userManager.CheckEmailAddress(model.User.EMAIL_ADDRESS) == true)
            {
                ModelState.AddModelError("EMAIL_ADDRESS", "Email is already taken");
                return View();
            }

            // check any existing username
            if (userManager.CheckUsername(model.User.USER_NAME) == true)
            {
                ModelState.AddModelError("USER_NAME", "Username is already taken");
                return View();
            }

            userManager.CreateUser(model.User);
            return RedirectToAction("Index", "Home");
        }
        
        [HttpGet]
        public ActionResult LogIn()
        {
            if (Session["CurrentUserID"] != null)
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        [HttpPost]
        public ActionResult LogIn(PB_USER userModel)
        {
            UserManager userManager = new UserManager();

            if (userManager.CheckEmailAddress(userModel.EMAIL_ADDRESS))
            {
                bool result = userManager.CheckPassword(userModel.EMAIL_ADDRESS, userModel.PASSWORD);

                if (result == true)
                {
                    // get user data
                    userModel = userManager.RetrieveUserByEmail(userModel.EMAIL_ADDRESS);
                    Session["CurrentUserID"] = userModel.ID;
                    Session["Username"] = userModel.USER_NAME;
                    Session["FirstName"] = userModel.FIRST_NAME;

                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("PASSWORD", "Incorrect Password");
                }
            }
            else
            {
                ModelState.AddModelError("PASSWORD", "Email or Password is entered incorrectly.");
            }

            return View();
        }

        public ActionResult LogOut()
        {
            Session.Abandon();
            return View("LogIn");
        }

        public JsonResult CheckEmail(string emailAddress)
        {
            UserManager userManager = new UserManager();
            bool result = userManager.CheckEmailAddress(emailAddress);
            return Json(new { Result = result });
        }

        public JsonResult CheckUsername(string username)
        {
            UserManager userManager = new UserManager();
            bool result = userManager.CheckUsername(username);
            return Json(new { Result = result });
        }

        public JsonResult CheckPassword(string email, string password)
        {
            UserManager userManager = new UserManager();
            bool result = userManager.CheckPassword(email, password);
            return Json(new { Result = result });
        }
    }
}