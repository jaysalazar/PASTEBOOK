﻿$(document).ready(function () {

    var username = {
        register: $('#txtUsernameRegister').val(),
        settings: $('#txtUsernameSettings').val()
    }

    var email = {
        register: $('#txtEmailRegister').val(),
        settings: $('#txtEmailSettings').val()
    }

    var password = {
        register: $('#txtPasswordRegister').val(),
        confirmRegister: $('#txtConfirmPasswordRegister').val(),
        settings: $('#txtPasswordSettings').val(),
        current: $('#txtCurrentPassword').val(),
        newPassword: $('#txtNewPassword').val(),
        confirmSettings: $('#txtConfirmPasswordSettings').val()
    }

    //register

    function CheckUsername(data) {
        if (data.Result == true) {
            $('#spnUsernameRegister').show();
        }
    }

    function CheckEmail(data) {
        if (data.Result == true) {
            $('#spnEmailRegister').show();
        }
    }

    function CheckPassword(data) {
        if (data.Result == true) {
            $('#spnPasswordRegister').show();
        }
    }

    function ConfirmPassword() {
        $('#spnConfirmPasswordRegister').show();
    }

    $('#txtUsernameRegister').on('blur', function () {
        $.ajax({
            url: CheckUsernameUrl,
            data: username.settings,
            type: 'GET',
            success: function (data) {
                CheckUsername(data);
            }
        });
    })

    $('#txtEmailRegister').on('blur', function () {
        $.ajax({
            url: CheckEmailUrl,
            data: email.register,
            type: 'GET',
            success: function (data) {
                CheckEmail(data)
            }
        });
    });

    $('#txtConfirmPasswordRegister').on('blur', function () {
        if (password.register != password.confirmRegister) {
            ConfirmPassword();
        }
    });

    //settings

    function CheckUsernameSettings(data) {
        if (data.Result == true) {
            $('#spnUsernameSettings').show();
        }
    }

    function CheckEmailSettings(data) {
        if (data.Result == true) {
            $('#spnEmailSettings').show();
        }
    }

    function CheckPasswordSettings(data) {
        if (data.Result == false) {
            $('#spnPasswordSettings').show();
        }
    }

    $('#txtUsernameSettings').on('blur', function () {
        $.ajax({
            url: CheckUsernameUrl,
            data: username.settings,
            type: 'GET',
            success: function (data) {
                CheckUsernameSettings(data);
            }
        });
    })

    $('#txtEmailSettings').on('blur', function () {
        $.ajax({
            url: CheckEmailUrl,
            data: email.settings,
            type: 'GET',
            success: function (data) {
                CheckEmailSettings(data);
            }
        });
    })

    $('#btnEmail').on('click', function () {
        $.ajax({
            url: CheckPasswordUrl,
            data: password.settings,
            type: 'GET',
            success: function (data) {
                CheckPasswordSettings(data);
            }
        });
    })

    $('#btnPass').on('click', function () {
        $.ajax({
            url: CheckPasswordUrl,
            data: password.current,
            type: 'GET',
            success: function (data) {
                CheckPasswordSettings(data);
            }
        });
    })

    $('#txtNewPassword').on('blur', function () {
        if (password.newPassword == password.current) {
            $('#spnConfirmNewPassword').show();
        }
    })

    $('#txtConfirmPasswordSettings').on('blur', function () {
        if (password.confirmSettings != password.newPassword) {
            $('#spnConfirmPasswordSettings').show();
        }
    })

    // settings

    $('#aEditInfo').on('click', function () {
        $('.frmViewInfo').hide();
        $('#aEditInfo').hide();
    });

    $('#aEditEmail').on('click', function () {
        $('#aEditEmail').hide();
    });

    $('#aEditPassword').on('click', function () {
        $('#aEditPassword').hide();
    });
});