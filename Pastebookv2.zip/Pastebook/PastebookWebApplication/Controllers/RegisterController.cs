﻿using PastebookWebApplication.Managers;
using PastebookWebApplication.Models;
using System.Web.Mvc;

namespace PastebookWebApplication.Controllers
{
    public class RegisterController : Controller
    {
        PasteBookManager manager = new PasteBookManager();

        // GET: Register
        public ActionResult Register(UserModel model)
        {
            ViewBag.Countries = manager.RetrieveAllCountries();
            return View(model);
        }

        [HttpPost]
        public ActionResult Details(UserModel model)
        {
            ViewBag.Countries = manager.RetrieveAllCountries();
            return View(model);
        }

        public JsonResult RegisterUser(UserModel userModel)
        {
            int result = manager.CreateUser(userModel);

            return Json(new { Result = result });
        }

        //public JsonResult RegisterUser(string username, string password)
        //{
        //    int result = manager.CreateUser(new UserModel() {
        //        Username = username,
        //        PasswordHash = password
        //    });

        //    return Json(new { Result = result });
        //}
    }
}